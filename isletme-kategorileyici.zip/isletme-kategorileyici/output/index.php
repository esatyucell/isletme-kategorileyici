<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <title>Kategoriler</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <h1> İşletme Kategorileri</h1>
    <ul>
        <li><a href="../kategori.php?kategori=bakkal">Bakkallar</a></li>
        <li><a href="../kategori.php?kategori=restoran">Restoranlar</a></li>
        <li><a href="../kategori.php?kategori=tekel">Tekel Bayileri</a></li>
    </ul>
</body>

</html>