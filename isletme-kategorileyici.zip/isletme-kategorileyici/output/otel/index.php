<!DOCTYPE html>
<html lang='tr'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>otel Kategorisi</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>
    <style>
        body { font-family: Arial, sans-serif; background: #f9f9f9; }
        .card { border-radius: 10px; margin-bottom: 15px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); }
        .card img { max-width: 100%; height: auto; border-radius: 10px; }
        .card-body { padding: 15px; }
        .card-title { font-size: 1.25rem; color: #333; }
        .card-text { font-size: 1rem; color: #555; }
        a { text-decoration: none; color: #007bff; }
        a:hover { color: #0056b3; }
    </style>
</head>
<body>
<div class='container py-4'>
    <h1 class='text-center mb-4'>otel Kategorisindeki İşletmeler</h1>
    <div class='row'><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed778d7.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4nr-ioiKYle0IhRWFpJOm1HmeyXy0qIJoUMswCD_RNCUOImEkr29T12AiCjFMo-dHKhaSWKWvw7u_VpUEK1ToGN9hgAOM4UX_k0pZ096lbKsCyrBXkalEKlFArph4A_lxpGcoMdc=w408-h306-k-no' class='card-img-top' alt='Tcdd Kule Restaurant'>
                <div class='card-body'>
                    <h5 class='card-title'>Tcdd Kule Restaurant</h5>
                    <p class='card-text'>Hacı Bayram, Hipodrom Cd. No:3, 06050 Altındağ/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed77a45.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4no7LbRgqAflqm6I8OblFxvb6QGMBlGOsyRab0_zqKraNAGXSjJqlCq6SpaxWgZoLGmoMf1tI7TSs8uxe2CGSyaJ1OB3rfziD1niD9oNNdzE7lG17mZgt9y8W4C12F0bQNjFlrLJ=w408-h306-k-no' class='card-img-top' alt='HMBRGR Bahçelievler'>
                <div class='card-body'>
                    <h5 class='card-title'>HMBRGR Bahçelievler</h5>
                    <p class='card-text'>Bahçelievler, Azerbaycan Cd. No:7, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed77b73.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4nri2F-kDIF9W1k2P2G_HKTQAuqWkN6VydIINC1Ums8enT2uRablGjrttXSjwWjNmGQFYKlnFZC1rO9vJkLM6066FPU2TBj0_kgcAZMLIb0c43cDYve-mD59F3T1ygYWw9WVREYe=w408-h306-k-no' class='card-img-top' alt='Kahveci Hacıbaba - Tandoğan'>
                <div class='card-body'>
                    <h5 class='card-title'>Kahveci Hacıbaba - Tandoğan</h5>
                    <p class='card-text'>Anıttepe, Gazi Mustafa Kemal Blv. No:139, 06570 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed77ca7.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4nrM9vZYN6T0NmTgBbVcJuO8ICFxbdgFVSxZ7fFmRmnC8QAy8dqkH33lrtojrR4aEsB1JhLK96iTZDTa1Eyt1LJnJZbXFu178kopbMWfQXsujGJu58-j2VkB-dRJKiuau00KR56E=w531-h240-k-no' class='card-img-top' alt='SÜSLÜ RESTAURANT'>
                <div class='card-body'>
                    <h5 class='card-title'>SÜSLÜ RESTAURANT</h5>
                    <p class='card-text'>Mebusevleri, Süslü Sk. No:2, 06580 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed77fc8.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipP8Ar6r_RNn6le98BUbZygV3Nj51ub63T0xfbFJ=w408-h271-k-no' class='card-img-top' alt='Kajun Bahçelievler'>
                <div class='card-body'>
                    <h5 class='card-title'>Kajun Bahçelievler</h5>
                    <p class='card-text'>Bahçelievler, Azerbaycan Cd. No: 13/1, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed78166.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipPf_TX164kGVudE8D4F3Wt4noXy_mQGEfVPS0TB=w408-h306-k-no' class='card-img-top' alt='Biisot Lahmacun&amp;Döner'>
                <div class='card-body'>
                    <h5 class='card-title'>Biisot Lahmacun&amp;Döner</h5>
                    <p class='card-text'>Bahçelievler, 58. Sk. No:16, 06530 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed782cd.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipOCirKU-oFvIjntvZJ_6oBDsLHVtb0eIEO2syAf=w426-h240-k-no' class='card-img-top' alt='Meşhur Yıldırım Aspava Tandoğan'>
                <div class='card-body'>
                    <h5 class='card-title'>Meşhur Yıldırım Aspava Tandoğan</h5>
                    <p class='card-text'>Mebusevleri, Anıt Cd. No:10 D:B, 06570 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed78424.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4npE7QG6-qVdUvdcscSg4EEYj5JvnVQSge8-D1gv6OE36sRNlOFPZNmrgfqWJMIT3YDAGyQmE1eagrOexiadZzOM_BLB8ntyg6Hy6vhHGAEcFgEJmLDZSacy8AFRAFmqGxKqJJZHfQ=w426-h240-k-no' class='card-img-top' alt='Ciğerci Aydın'>
                <div class='card-body'>
                    <h5 class='card-title'>Ciğerci Aydın</h5>
                    <p class='card-text'>Maltepe Mahallesi, Eti, Gazi Mustafa Kemal Blv. No:122 D:B, 06570 Çankaya, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed785aa.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4nqFAQMrzQ2Eu1ow_BeTHFlTgiCakmsV5RfPanPuRoCMu7S8ltc6IbGwNuCYPUVLdXVQ9g6fGu3uSBx_vckYQSfgz3uPWS2YelhhbMmnsTk-a9GwYCCAYx9qgEA-A3cK_6jvW2pjHA=w408-h306-k-no' class='card-img-top' alt='Ravi'>
                <div class='card-body'>
                    <h5 class='card-title'>Ravi</h5>
                    <p class='card-text'>Dr, Bahçelievler, Prof. Muammer Aksoy Cd No: 41/A, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed786d5.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4npi2smVJgh7cqhQMdEm2yGGvaXlW6g1cOOCrSDrLUg73twCelxhO4I2MsS3iIOSGopZeHZuhQn6AMUSsBbVDEm6cXl2pW07pTvxLp6fIwdK8G45BpyTQrDE8FSxaWS0Tza9nDT_Cg=w426-h240-k-no' class='card-img-top' alt='Modern Piknik'>
                <div class='card-body'>
                    <h5 class='card-title'>Modern Piknik</h5>
                    <p class='card-text'>Tandoğan, Dögol Cd. No:29/C, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed788bb.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipN6c7unm-I-96adLX8LYBXRtlUZ1-hy2HA7E8dA=w408-h272-k-no' class='card-img-top' alt='Loophole Booze Bite &amp; Fun'>
                <div class='card-body'>
                    <h5 class='card-title'>Loophole Booze Bite &amp; Fun</h5>
                    <p class='card-text'>Mareşal Fevzi Çakmak Caddesi No:18 Beşevler, 06500 Beşevler, Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7ada7.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4npTz-LeGDajdp2bz6IZzJXEZWr4IuE2y0mn6CsjEv_OGbCcYwfWDbk0O98fDTCcafAF0yAtA_0m-JmQZT_e_EYCXMRAuI_tYyFNCsFEaZrCpdlAiBa8ncB6Q0fFUP5q_wfGu2Pk2w=w408-h543-k-no' class='card-img-top' alt='Antep Şiş Kebap'>
                <div class='card-body'>
                    <h5 class='card-title'>Antep Şiş Kebap</h5>
                    <p class='card-text'>Bahçelievler, Azerbaycan Cd. 29/A, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7bd3d.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipPqGFY6Le51AFHMgieXj4eh6zecVDXF1DH0fvLh=w408-h271-k-no' class='card-img-top' alt='Mihrace Restoran'>
                <div class='card-body'>
                    <h5 class='card-title'>Mihrace Restoran</h5>
                    <p class='card-text'>Eti, Gazi Mustafa Kemal Blv. No:98/B, 06570 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7bee3.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipMNXZ273nBxTIy0S2GQXr79FAHxmMNEXRWefGLz=w408-h272-k-no' class='card-img-top' alt='Yıldız Aspava Beşevler'>
                <div class='card-body'>
                    <h5 class='card-title'>Yıldız Aspava Beşevler</h5>
                    <p class='card-text'>Mebusevleri, Dögol Cd. 33/B, 06600 Tandoğan - Çankaya/Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7c048.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4nqwGLZZZ3cejIitSbcLo2ZWsFiRmAbxNii4yXXv7JGPCEp_gZWkMjR0H6nvHBB-PGjgvCGcm0Z9M_4hVjMWODPZmG8wJeAAE0fqnLLE36kjAKdzbG8PDyHP-ZvmnOiXYKWTnxTS=w408-h306-k-no' class='card-img-top' alt='Last Penny Bahçelievler'>
                <div class='card-body'>
                    <h5 class='card-title'>Last Penny Bahçelievler</h5>
                    <p class='card-text'>Bahçelievler, Prof. Muammer Aksoy Cd No:51, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7c1db.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4nrA6r6rxL6uLgGew4VP5lMnZxMw_OVJP6CbLhcuSqvgaVs4S1yrhUqqW-JTGTdujlauAJSw_iPDxdQGuxr-sFSIiMdGhKIUBnoK3pCCI8lFuDlNWT0V5ZlGI4A-NujK2Ah85S87kw=w426-h240-k-no' class='card-img-top' alt='Marco Pascha Bahçelievler'>
                <div class='card-body'>
                    <h5 class='card-title'>Marco Pascha Bahçelievler</h5>
                    <p class='card-text'>Yukarı Bahçelievler, Aşkabat Cd. No:18, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7c503.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4nqeGNNpbMY_7WydfvV5bgQ0GJ1c8k7cYXo9Lu0_EB-oAXyvWCo9MereGjVIuN26HlvlRDZyoOVDeRabIDxo-NRkIma_hKPmFXPDM8Wy1veTWGezVZYfEwhUzJEbqy78zEErVmpYHw=w408-h460-k-no' class='card-img-top' alt='Kalite 1 Karadeniz Pideleri'>
                <div class='card-body'>
                    <h5 class='card-title'>Kalite 1 Karadeniz Pideleri</h5>
                    <p class='card-text'>Maltepe, Gazi Mustafa Kemal Bulv./çatal Sok. 3/C, 06570 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7c692.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipOOkneR2PPYVDg6ztwT1RIrGtxz7i3uQ0lW5E_-=w408-h306-k-no' class='card-img-top' alt='İŞLER GÜÇLER IZGARA &amp; KOKOREÇ'>
                <div class='card-body'>
                    <h5 class='card-title'>İŞLER GÜÇLER IZGARA &amp; KOKOREÇ</h5>
                    <p class='card-text'>Bahçelievler, Taşkent Cd. 19/B, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7c7d3.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4np-wgIdXu16osvi7KaEY6zAi5RfbQpDku55uBkdXIaHHFSGvmz0FVIrXz0cFlia4rlfIg2B1EMNMblh27d62PLcQAyerWSoyQey_yTsByNvEDXaZpI6eOhKwVjomdl9N8yoX0pAkQ=w408-h306-k-no' class='card-img-top' alt='ŞİMŞEK ASPAVA BAHÇELİEVLER'>
                <div class='card-body'>
                    <h5 class='card-title'>ŞİMŞEK ASPAVA BAHÇELİEVLER</h5>
                    <p class='card-text'>Bahçelievler, Azerbaycan Cd. 19/A, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7c8f7.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4npJJ3jdtOEJ3_1M3qgUQk9W5rWEPIx4SVp-1L7uIbt1cdb3nQCGZJaHC11E4XPx9WA_Zd4ygoWiBr_D5x_pEe4RrlNWoT-sReeou2apSN637ZrZHUmEv5fC0c7uCx4kFe5dRjQ=w408-h306-k-no' class='card-img-top' alt='GOOD BEEF BEŞEVLER'>
                <div class='card-body'>
                    <h5 class='card-title'>GOOD BEEF BEŞEVLER</h5>
                    <p class='card-text'>Bahçelievler, Dögol Cd. 63a, 06900 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7ca21.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipP_x36FXKSECogcxPCNalEZ47OWUnrPTNvRkzV_=w408-h306-k-no' class='card-img-top' alt='Türkiye Büyük Millet Meclisi Sosyal (Ala) Tesisleri'>
                <div class='card-body'>
                    <h5 class='card-title'>Türkiye Büyük Millet Meclisi Sosyal (Ala) Tesisleri</h5>
                    <p class='card-text'>Emniyet, 06560 Yenimahalle/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7cb48.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipO4ANDH15zLvvkfNxTHhHqEWpKY68rnUyQrQf8-=w408-h544-k-no' class='card-img-top' alt='Tbmm Eğitim ve Sosyal Tesisleri(Ala Restoran)'>
                <div class='card-body'>
                    <h5 class='card-title'>Tbmm Eğitim ve Sosyal Tesisleri(Ala Restoran)</h5>
                    <p class='card-text'>Emniyet, 06560 Yenimahalle/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7d8c0.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipMuFd4cdn-XHzOv5m3mFNqXR1uWZ1eE-qDkAOWR=w425-h240-k-no' class='card-img-top' alt='TBMM Beşevler Sosyal Tesisleri'>
                <div class='card-body'>
                    <h5 class='card-title'>TBMM Beşevler Sosyal Tesisleri</h5>
                    <p class='card-text'>Beştepe, Alparslan Türkeş Cd. No:69, 06560 Yenimahalle/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7da73.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipPEBRwYm00Sn16riVKga4aeWnqLtymyUQrnKIF7=w408-h544-k-no' class='card-img-top' alt='Ceviz'>
                <div class='card-body'>
                    <h5 class='card-title'>Ceviz</h5>
                    <p class='card-text'>Emniyet, WRQ9+JG, 06560 Yenimahalle/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7db9b.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipNJljcnQfivzjH6AtmUPWVDAJReo2M-s78Yhosm=w408-h306-k-no' class='card-img-top' alt='Tarihi İnegöl Köftecisi Nevzat Usta'>
                <div class='card-body'>
                    <h5 class='card-title'>Tarihi İnegöl Köftecisi Nevzat Usta</h5>
                    <p class='card-text'>Emek, Bişkek Cd. 21/A, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7dd2d.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipMnQFzNS_D-wG5BTzDpreE1rtcbCvrhAcd2LKNK=w408-h544-k-no' class='card-img-top' alt='Beard beer'>
                <div class='card-body'>
                    <h5 class='card-title'>Beard beer</h5>
                    <p class='card-text'>Bahçelievler, Azerbaycan Cd. 12/A, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7de59.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipOVLabS3DraYNnaOYNupT9cVG0mr6OLvbCIU3Fd=w408-h306-k-no' class='card-img-top' alt='Seyir Cafe'>
                <div class='card-body'>
                    <h5 class='card-title'>Seyir Cafe</h5>
                    <p class='card-text'>Bahçelievler, Prof. Muammer Aksoy Cd No:2, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7e105.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipPAdE-6NOnbNO0uQXf8y9IOHuK0cWJYVZH-qMGy=w566-h240-k-no' class='card-img-top' alt='Ankara Hamsi'>
                <div class='card-body'>
                    <h5 class='card-title'>Ankara Hamsi</h5>
                    <p class='card-text'>Beştepe, Alparslan Türkeş Cd. 11/A, 06330 Yenimahalle/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7ece1.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipM5P30cp4P8Z3H5yF3nUBsmXnjjwRl7TxCzoCbS=w408-h306-k-no' class='card-img-top' alt='Kasap Izgara'>
                <div class='card-body'>
                    <h5 class='card-title'>Kasap Izgara</h5>
                    <p class='card-text'>Emek, Kazakistan Cd. No:74/C, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7ee5b.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipMSn7vgZAb9nckqlpUvWDvPXnbmL6LxX9BVHzgQ=w408-h274-k-no' class='card-img-top' alt='Türkiye Rabota club dans'>
                <div class='card-body'>
                    <h5 class='card-title'>Türkiye Rabota club dans</h5>
                    <p class='card-text'>Maltepe, Akıncılar Sk. 1/B, 06570 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7ef82.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4noDyjhC28Ja0selsnyuVyv4xTt0L99LViMm-PV2_oryglN8bSBx8NyeYzfdMvHoMoOS132QVfeJgajhg3kbxyHuaJ6pCSamC1DuE-tv-Pbrxn2gnbuY-2uHZuZAXaVon7YQRwYg=w408-h544-k-no' class='card-img-top' alt='SushiGoo Day'>
                <div class='card-body'>
                    <h5 class='card-title'>SushiGoo Day</h5>
                    <p class='card-text'>Anıttepe, Kubilay Sk. No:4, 06570 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7f0a3.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4np9iTLIcqOD8WHU5Cdc90tdB_JYPrBvkbc-MN2zzveqoSYbOkUQt1RWZXonP_n6ByVxRTeZqvlzRz5QuJB2Vd_0oU-4bSa3O6zDCTic6BpcQnbVQURaBzsiWbVOpVdt1F80eMND=w408-h545-k-no' class='card-img-top' alt='Necmi Ustanın Yeri'>
                <div class='card-body'>
                    <h5 class='card-title'>Necmi Ustanın Yeri</h5>
                    <p class='card-text'>Durak Pasajı, Maltepe, Gazi Mustafa Kemal Blv. No:117 D:P, 06430 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7f1b5.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4npn8w83ex_VvNJmIoKxLzvET1iMTxh-01Kqad587TnXDiaEWSFw1NQR-D4E3RPAqB1zMEAtt8_JlBXeTxZQXFfu0FsXtpHwgY5oAzESmiixycwM0hcomjrEcq5E0oXNt6x_8nyf=w408-h306-k-no' class='card-img-top' alt='Korykos Tantuni'>
                <div class='card-body'>
                    <h5 class='card-title'>Korykos Tantuni</h5>
                    <p class='card-text'>Mebusevleri, Maltepe, Dögol Cd. 25-A, 06580 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7f2c4.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipNewvzEUXEdcU2NWX4hz8s7oYWgmLeQIY2hy0g_=w426-h240-k-no' class='card-img-top' alt='Meşhur Acıyaman Çiğköftecisi'>
                <div class='card-body'>
                    <h5 class='card-title'>Meşhur Acıyaman Çiğköftecisi</h5>
                    <p class='card-text'>Beştepe, Mecnun Sk. No:20, 06560 Yenimahalle/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7f3f0.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipM8lOtqZvJmObZq5hTfvf5v6vXNjtMfqcmrMsCH=w408-h306-k-no' class='card-img-top' alt='Şantiye'>
                <div class='card-body'>
                    <h5 class='card-title'>Şantiye</h5>
                    <p class='card-text'>Bahçelievler, Azerbaycan Cd. No:24, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7f516.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipPmeu7HTxpbQ3ETKJsK8nup6aEX7f4xig-4wOCl=w426-h240-k-no' class='card-img-top' alt='Öz Hanedan İskender'>
                <div class='card-body'>
                    <h5 class='card-title'>Öz Hanedan İskender</h5>
                    <p class='card-text'>Mebusevleri, Dögol Cd. No:25, 06580 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7f640.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipND7l023iYGypgJC-9eoCVDX5rWmvbPfGOK5NiG=w408-h271-k-no' class='card-img-top' alt='Mamazara Coffee Kitchen'>
                <div class='card-body'>
                    <h5 class='card-title'>Mamazara Coffee Kitchen</h5>
                    <p class='card-text'>Bahçelievler, 35. Cadde No:14, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7f76b.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipNO21kSHg2oL7H_cBjq9zVF42G69cBCzFRePju6=w408-h306-k-no' class='card-img-top' alt='Adem Usta Meşhur Köfteci'>
                <div class='card-body'>
                    <h5 class='card-title'>Adem Usta Meşhur Köfteci</h5>
                    <p class='card-text'>Maltepe, Onur Sk. 23/B, 06570 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed7f8a8.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipNo69hyWEAre4XHR1I8CwSrrYDWJBteh-xHq5_c=w408-h272-k-no' class='card-img-top' alt='Kovan Bistronomy'>
                <div class='card-body'>
                    <h5 class='card-title'>Kovan Bistronomy</h5>
                    <p class='card-text'>Talatpaşa Bulvarı, No: 38 Opera, 06330 Altındağ/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed80d23.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4np1JuOvSwek-B9hTeo0y9FbbMGZq-oXxLE3T_KvW4bKA-VOrwLpiJr12YhTseNV18rPfjw94GubPw8Icjw7-tHBb_o4opROBkn8sB7JCPD_wQEzhdoyf-HI87J3FqIqvRrAMnT5=w408-h306-k-no' class='card-img-top' alt='Route NY'>
                <div class='card-body'>
                    <h5 class='card-title'>Route NY</h5>
                    <p class='card-text'>Bahçelievler, Azerbaycan Cd. No:41, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed80eb9.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4nqjBHt7P-SGjSj_ydUlS_d2o50Cw0yu8PiTKyYAJTmYxFH993QiL8f6Hv5rplZeM0Zs7K6fSoZ0BTEnRBl3ZQ5xfOheSxrnbFVq4MRWvbGGxr14WmwzsrPCfPH9InVBtbTsb63w=w513-h240-k-no' class='card-img-top' alt='Big Baker'>
                <div class='card-body'>
                    <h5 class='card-title'>Big Baker</h5>
                    <p class='card-text'>Bahçelievler, Prof. Muammer Aksoy Cd No:10, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed80fe3.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4nqek7pw3rINpONZ0H_ojqktYAhL3gdBkFjx3aHQODcwhx3yFOxvzC9YM9bPM0eF1q4roC_wcH0s78XNw7xlVqmm9hBzVIDPqmTamMyWaDd2UsK2b2tXCSlv4afkUak0OnuMMMg7Og=w408-h306-k-no' class='card-img-top' alt='Çınaraltı İşkembe Ve Lokantası'>
                <div class='card-body'>
                    <h5 class='card-title'>Çınaraltı İşkembe Ve Lokantası</h5>
                    <p class='card-text'>Maltepe, Gazi Mustafa Kemal Blv. 93/A, 06570 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed8110d.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4noQk4zz7fbdI5Cnn1_Ge7pU28Ap8GTAW6tExeLSEdamUjMkS5hgU-EQvxKKQr-lp29XGMaxvWmunpzYCuBkA79nGP-U2kVN4BaYNYl-SfKqiKYqmJj2KQ_92gOpTjsBwo1vxGE=w408-h306-k-no' class='card-img-top' alt='Eski Meyhane'>
                <div class='card-body'>
                    <h5 class='card-title'>Eski Meyhane</h5>
                    <p class='card-text'>Bahçelievler, Azerbaycan Cd. No:41, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed81220.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4nrlG0Ns1i7bjLCaKt9ZWY_L_obOMFjj42tsk281NEpxzLE3YDTOfx5vnzFe8usn7fhphiJ3KVHBMn4nTPErWqSnoznb1LV1OdFGocD2uLzkoe4tQfFBdDYZp0McBcj2gvklM_nUvQ=w486-h240-k-no' class='card-img-top' alt='BURRGARR'>
                <div class='card-body'>
                    <h5 class='card-title'>BURRGARR</h5>
                    <p class='card-text'>Eti, Celal Bayar Blv. No:78, 06560 Yenimahalle/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed8133c.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/CpMDRb_EySzF_dLs2ewO0Cz1fO4RHf-9D0sUcP5NTD8bU3YiLsrsH05luj0iTpYhFQ=w426-h240-k-no' class='card-img-top' alt='Huzur Aspava'>
                <div class='card-body'>
                    <h5 class='card-title'>Huzur Aspava</h5>
                    <p class='card-text'>no: d:12, Anıttepe, Kubilay Sk. No:39, 06580 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed8144e.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4npJikd0_hOdsfi2DLMj6s82JRksn3tdXW8eH1JZiYlag7kSdDS3EOW5kjaZHniyrJiWxdeQM6Xr6M2g3KsMRibOc7VA90YSZg-18dhn3FmpaGEPVv8TMhyfe5Bvl8wKsd06ja6W=w408-h306-k-no' class='card-img-top' alt='Port Heaven'>
                <div class='card-body'>
                    <h5 class='card-title'>Port Heaven</h5>
                    <p class='card-text'>Tev Binasinda, Eti, Gazi Mustafa Kemal Blv. 68/A, 06680 Maltepe/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed8156b.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4npPtVC00rIb7MODpAfY-X2fUhbYgzu9fWOTS6rZGaOWY7L4an4AdU78q1wcHvx3QEETIiUGu_YwoXuz8s3wgGRizpiZfgfdaNT3dNofJKRHWxnazm5YYBzU3Vs_RivBKxfyRwkq=w408-h306-k-no' class='card-img-top' alt='Sven Pub'>
                <div class='card-body'>
                    <h5 class='card-title'>Sven Pub</h5>
                    <p class='card-text'>Bahçelievler, Prof. Muammer Aksoy Cd No:29/A, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed81688.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipOgYAOjbnWBINQN13WO85TgW7_PXq04Cr3OQkrX=w408-h306-k-no' class='card-img-top' alt='Unique Burgers'>
                <div class='card-body'>
                    <h5 class='card-title'>Unique Burgers</h5>
                    <p class='card-text'>Bahçelievler, Prof. Muammer Aksoy Cd 7-A, 06450 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed8178e.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4nrFWt3G_UdTSU3KQNHauNJ6VhFrCFdkJ9Bc8e92Kkt9JX3WRi8e4VYDLqHneyRWF061tofEh00sUDAeZFBh53qNFbNUGH-lSw7qDbHjmcq-G30b1xbMR0YNZjoJ2_VWf5I2feqlQw=w426-h240-k-no' class='card-img-top' alt='SungurBey'>
                <div class='card-body'>
                    <h5 class='card-title'>SungurBey</h5>
                    <p class='card-text'>Bahçelievler, Bahriye Üçok Cd. 15/A, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed818b2.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipOL-c-1-SYivhZQ30Cz9RrS0IlHe3CRln5E3DJI=w426-h240-k-no' class='card-img-top' alt='Agah Cafe &amp; Gözleme Unlu Mamüller Yöresel Ürünler'>
                <div class='card-body'>
                    <h5 class='card-title'>Agah Cafe &amp; Gözleme Unlu Mamüller Yöresel Ürünler</h5>
                    <p class='card-text'>Bahçelievler, Taşkent Cd. No:39, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed819c9.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipN-k9au4E9Oz1T7B9Ej2jyOfUgGWl2qluyAJSWc=w408-h884-k-no' class='card-img-top' alt='ADA PİLAV'>
                <div class='card-body'>
                    <h5 class='card-title'>ADA PİLAV</h5>
                    <p class='card-text'>Bahçelievler, Dögol Cd. 67/A, 06200 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed81ae2.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipPmnbiQzx4XRI4oyh2_SUNWfiOSWIASKaBCD1-K=w613-h240-k-no' class='card-img-top' alt='squisito'>
                <div class='card-body'>
                    <h5 class='card-title'>squisito</h5>
                    <p class='card-text'>Bahçelievler, Prof. Muammer Aksoy Cd No:41 D:1, 06560, 06490 Bahçelievler/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed83109.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipMExBjY1iJZsqjSMFos1rHAYnDC4XwAi8lddaKn=w425-h240-k-no' class='card-img-top' alt='Derviş Sofrası'>
                <div class='card-body'>
                    <h5 class='card-title'>Derviş Sofrası</h5>
                    <p class='card-text'>Emniyet, Alparslan Türkeş Cd. 13/A, 06560 Yenimahalle/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed8330a.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipNI58OVRXRabbTF4JQL3slXbSbzz-ftc0VbAWUj=w408-h272-k-no' class='card-img-top' alt='Ahal Teke Binicilik Tesisleri'>
                <div class='card-body'>
                    <h5 class='card-title'>Ahal Teke Binicilik Tesisleri</h5>
                    <p class='card-text'>Emniyet, Alparslan Türkeş Cd. No: 12, 06560 Yenimahalle/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed83e09.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipNCV2VdXsYZg2EYKB2BRdsQv4gVpDkSDO5-ywE8=w408-h306-k-no' class='card-img-top' alt='ANKARA BİNİCİLİK İHTİSAS KULÜBÜ BİNİCİLİK RESTAURANT'>
                <div class='card-body'>
                    <h5 class='card-title'>ANKARA BİNİCİLİK İHTİSAS KULÜBÜ BİNİCİLİK RESTAURANT</h5>
                    <p class='card-text'>Emniyet, 06560 Yenimahalle/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed83f9e.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipMnHGENtSFqJrEICIYLxJDtzI6SQhxWw8Y-kCEh=w408-h306-k-no' class='card-img-top' alt='Castello Döner'>
                <div class='card-body'>
                    <h5 class='card-title'>Castello Döner</h5>
                    <p class='card-text'>Bahçelievler, Taşkent Cd. No:8, 06490 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed8688e.html'>
            <div class='card'>
                
                <div class='card-body'>
                    <h5 class='card-title'>Meşhur Köfteci Adem Usta Beştepe</h5>
                    <p class='card-text'>Beştepe, Misket Sk. No:18, 06560 Yenimahalle/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed87e82.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipNOnLSa7WRge_nGYi7yd3i3c7E5qLaeGE5bmR6s=w426-h240-k-no' class='card-img-top' alt='Simge Piknik'>
                <div class='card-body'>
                    <h5 class='card-title'>Simge Piknik</h5>
                    <p class='card-text'>Mebusevleri, Dögol Cd. No:29 D:C, 06580 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed87fe3.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/p/AF1QipN9UH6mA5oWMbU-x503ZIRbwqSG7lVvzoySG2Tx=w408-h725-k-no' class='card-img-top' alt='Beşevler Gece Dönercisi'>
                <div class='card-body'>
                    <h5 class='card-title'>Beşevler Gece Dönercisi</h5>
                    <p class='card-text'>Mebusevleri, Dögol Cd. No:51B, 06570 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div><div class='col-md-4 col-sm-6'>
        <a href='682fc7ed8810a.html'>
            <div class='card'>
                <img src='https://lh3.googleusercontent.com/gps-cs-s/AC9h4nq5DWs2NsMK6qKgKBHLpqQlDC3BwF9jcpxM3NXHU95McQCihrQEUDR4w7gilWN-oFm6XWp_tiC3I1yVO2u-4gEYoVt7Rn6QX2-oaGBYDls2deHGYF4rSVE2OyB-iARqK5WJwfU=w408-h725-k-no' class='card-img-top' alt='Ayder Piknik'>
                <div class='card-body'>
                    <h5 class='card-title'>Ayder Piknik</h5>
                    <p class='card-text'>Maltepe, Akıncılar Sk. 1/D, 06570 Çankaya/Ankara, Türkiye</p>
                </div>
            </div>
        </a>
    </div></div></div></body></html>